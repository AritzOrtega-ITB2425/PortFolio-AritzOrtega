const cambiar_fondo = document.getElementById('cambiar_fondo');

cambiar_fondo.addEventListener('click', () => {
  document.body.classList.toggle('oscuro');
});